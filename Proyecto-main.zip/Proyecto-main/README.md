# Proyecto Cursos Online

# Integrantes

- Ortiz Zuñiga
- Triviño Moreira
- Larrosa Dylan
- Cervantes Alfredo

# Course.springframework.model

![Captura de pantalla (2389)](https://github.com/Alejandroortiz22/Proyecto/blob/main/Captura/Captura1.png)

# Public class: Course.springframework.model

![Captura de pantalla (2390)](https://github.com/Alejandroortiz22/Proyecto/blob/main/Captura/Captura2.png)

# ProductCategory

![Captura de pantalla (2391)](https://github.com/Alejandroortiz22/Proyecto/blob/main/Captura/Captura3.png)

# Controller, Autowired, Getmapping

![Captura de pantalla (2392)](https://github.com/Alejandroortiz22/Proyecto/blob/main/Captura/Captura4.png)

# Ejecución
Ruta hacia los diferentes cursos online 

![Captura de pantalla (2395)](https://github.com/Alejandroortiz22/Proyecto/blob/main/Captura/Captura6.png)

![Captura de pantalla (2396)](https://github.com/Alejandroortiz22/Proyecto/blob/main/Captura/Captura7.png)

![Captura de pantalla (2397)](https://github.com/Alejandroortiz22/Proyecto/blob/main/Captura/Captura8.png)

![Captura de pantalla (2398)](https://github.com/Alejandroortiz22/Proyecto/blob/main/Captura/Captura9.png)
